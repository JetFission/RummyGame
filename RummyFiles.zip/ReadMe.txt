Began Working On Card Sorting And Meld Detection
*Works With Deck On RCE.cpp
*Implemented on GHR.cpp For Hands, But Doesn't Work. Refuses To Return 0.