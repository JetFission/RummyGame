#include <iostream>
#include "GettingHandsReady.cpp"
using namespace std;


void MakeTable(){
int csize = 10;	
int psize = 10;	
char dummychar;

int Pscore = 0; //players total score
int Cscore = 0; //comp's total score

int PHDead; //deadwood in players hand
int CHDead; //deadwood in computers hand

int Stocksize = 0; //decl size;
int dissize = 0; //discard size

int round;

cout << "****************************************************************" << endl;
cout << "* Player Score:" << Pscore << "\tStock Size:" << Stocksize << "\t\tTop Card:" << "XX" << "    *" << endl;
cout << "* Computer Score:" << Cscore << "\tDiscard Size:" << dissize << "\t\tRound:" << round << "\t       *" <<endl;
cout << "****************************************************************" << endl;

cout << "\t\t\t::Computers Hand::\n\t\t";
for(int i = 0; i < csize; ++i){
cout << "??" << "  ";
}

cout << "\n\n";

cout << "\t\t\t::Players Hand::\n\t\t";
for(int i = 0; i < csize; ++i){
cout << "XX" << "  ";
}
cout << endl;
cout << "****************************************************************" << endl;
cout << "Melds:: " << "[Place Holder]" << endl;
cout << "Dead Wood:: " << "[Place Holder]" << endl;
cout << "****************************************************************" << endl;
cout << "\t\t\t   ::Player Actions::" << endl;
cout <<"\t\tA)Play\tB)Draw\tC)Move\tD)View\tE)Exit" << endl;
cout <<"\t\tPlease Select Action::";
cin >> dummychar;
cout << endl;
}




int main(){
	
MakeTable(); //Sets up Game Board	



return 0;
}
