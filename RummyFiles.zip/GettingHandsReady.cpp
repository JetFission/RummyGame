#include <iostream>       // std::cout
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
#include <ctime>
#include <cstdlib>
using namespace std;


int myrandom(int i) { return rand() % i; }

struct Card
{
	string suit;
	char card;
	int deadwoodVal;
};




int main()
{
	
	
	srand(time(0)); //each shuffle will be different

	vector<Card> deck;
	Card d; //used to load cards into the vector

string suit[4] =  { "_Hrt", "_Dia", "_Clb", "_Spd" }; //Heart, Diamond, Club, Spade
char card[13] = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'}; //Accepted Values

	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 13; j++){
			d.suit = suit[i];
			d.card = card[j];
			
			
			//Assigns Deadwood Values to each Card
			if(card[j] == 'A'){
			d.deadwoodVal = 1;	
			}
			else if ((card[j] == 'T')||(card[j] == 'J')||(card[j] == 'Q')||(card[j] == 'K')){
			d.deadwoodVal = 10;
			}
			else if((card[j] <= '9')&&(card[j] >= '2')){
			d.deadwoodVal = card[j] - '0';
			};
			
			

			deck.push_back(d);
		}
	}

	random_shuffle(deck.begin(), deck.end() , myrandom); //shuffles the deck

	//---------------New Part 4/12/2017 9:00 am---------------//


    vector<Card> player; //players hand
    vector<Card> computer; //computers hand

    Card inter;


    for(int i = 0; i < 10; i++){ //load players hand and delete the cards taken from the deck
        inter.card = deck[i].card;
        inter.suit = deck[i].suit;
		inter.deadwoodVal = deck[i].deadwoodVal;
		
        player.push_back(inter);

        deck.erase(deck.begin(), deck.begin()+1);

    }

    for(int i = 0; i < 10; i++){ //load Computers hand and delete the cards taken from the deck
    
        inter.card = deck[i].card;
        inter.suit = deck[i].suit;
		inter.deadwoodVal = deck[i].deadwoodVal;
        computer.push_back(inter);

        deck.erase(deck.begin(), deck.begin()+1);

    }

    cout << "-------------Players hand------------------" << endl;
    cout << endl;

    for(unsigned int i = 0; i < player.size(); i++){
        //cout << player[i].suit << "\t" << player[i].card << endl;
        cout << player[i].card << player[i].suit << "  " << player[i].deadwoodVal << endl;
    }

    cout << endl;



    cout << "-------------Computers hand-----------------" << endl;
    cout << endl;

    for(unsigned int i = 0; i < computer.size(); i++){
        cout << computer[i].card << computer[i].suit << "  " << computer[i].deadwoodVal << endl;
    }



    cout << "----------Deck after drawing cards----------" << endl;
    cout << endl;
    int amount = 0;


    for(unsigned int i = 0; i < deck.size(); i++){
        cout << deck[i].card << deck[i].suit << " " << deck[i].deadwoodVal << endl;
        amount++;
    }

    cout << "Should have less than 52 cards, does it? " << amount << endl;


	return 0;
}
