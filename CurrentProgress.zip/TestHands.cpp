#include <iostream>       // std::cout
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include "Class.cpp"



using namespace std;
int myrandom(int i) { return rand() % i; }
Card d; //used to load cards into the vector
vector<Card> deck;
vector<Card> player; //players hand
vector<Card> computer; //computers hand
Card inter;
int amount = 0;
int handslot;



void PrepareDeck(){		
	srand(time(0)); //each shuffle will be different
	string suit[4] =  { "_Hrt", "_Dia", "_Clb", "_Spd" }; //Heart, Diamond, Club, Spade
	char card[13] = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'}; //Accepted Values

	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 13; j++){
		d.suit = suit[i];
		d.value = card[j];
			
		//Assigns Deadwood Values and Order Weight to each Card
		if(card[j] == 'A'){d.deadwoodVal = 1;d.orderVal = 1;}
		else if (card[j] == 'T'){d.deadwoodVal = 10;d.orderVal = 10;}			
		else if (card[j] == 'J'){
		d.deadwoodVal = 10;d.orderVal = 11;	}
		else if (card[j] == 'Q'){
		d.deadwoodVal = 10;d.orderVal = 12;	}
		else if (card[j] == 'K'){d.deadwoodVal = 10;d.orderVal = 13;}
		else if((card[j] <= '9')&&(card[j] >= '2')){d.deadwoodVal = card[j] - '0';d.orderVal = card[j] - '0';};
			
		deck.push_back(d);
		}}

	random_shuffle(deck.begin(), deck.end() , myrandom); //shuffles the deck

	//---------------New Part 4/12/2017 9:00 am---------------//
}





void Deal(){
  
	for(int i = 0; i < 10; i++){ //load players hand and delete the cards taken from the deck
        inter.value = deck[i].value;
        inter.suit = deck[i].suit;
		inter.deadwoodVal = deck[i].deadwoodVal;
		inter.orderVal = deck[i].orderVal;
		
        player.push_back(inter);
        deck.erase(deck.begin(), deck.begin()+1);
    }
	
	
    for(int i = 0; i < 10; i++){ //load Computers hand and delete the cards taken from the deck
    
        inter.value = deck[i].value;
        inter.suit = deck[i].suit;
		inter.deadwoodVal = deck[i].deadwoodVal;
		inter.orderVal = deck[i].orderVal;
		
        computer.push_back(inter);
        deck.erase(deck.begin(), deck.begin()+1);
    }
    
   //----------Deck after drawing cards----------
   for(unsigned int i = 0; i < deck.size(); i++){amount++;}
   }//end of Deal()





void SortP(){ //Sorts Player Hand
//Sort by Suit
for(int x = 0; x < 52; ++x){
for(handslot = 0; handslot <( player.size() - 1); ++ handslot){
if(player[handslot].suit < player[handslot + 1].suit){
p1 = player[handslot].value;
p2 = player[handslot].suit;
p3 = player[handslot].deadwoodVal;
p4 = player[handslot].orderVal;

player[handslot].suit = player[handslot + 1].suit;
player[handslot].value = player[handslot + 1].value;
player[handslot].deadwoodVal =player[handslot + 1].deadwoodVal;
player[handslot].orderVal = player[handslot + 1].orderVal;
player[handslot + 1].value = p1;
player[handslot +1].suit = p2;
player[handslot +1].deadwoodVal =p3;
player[handslot +1].orderVal =p4;
}}}//************************************


for(int x = 0; x < 152; ++x){
for(handslot = 0; handslot < (player.size() -1); ++handslot){//====
if((player[handslot].orderVal > player[handslot + 1].orderVal)&&(player[handslot].suit == player[handslot + 1].suit)){
p1 = player[handslot].value;
p2 = player[handslot].suit;
p3 = player[handslot].deadwoodVal;
p4 = player[handslot].orderVal;

player[handslot].suit = player[handslot + 1].suit;
player[handslot].value = player[handslot + 1].value;
player[handslot].deadwoodVal =player[handslot + 1].deadwoodVal;
player[handslot].orderVal = player[handslot + 1].orderVal;
player[handslot + 1].value = p1;
player[handslot +1].suit = p2;
player[handslot +1].deadwoodVal =p3;
player[handslot +1].orderVal =p4;
}}};

}//end of SortP();


void SortC(){ //Sorts Comp Hand
//Sort by Suit
for(int x = 0; x < 52; ++x){
for(handslot = 0; handslot <( computer.size() - 1); ++ handslot){
if(computer[handslot].suit < computer[handslot + 1].suit){
p1 = computer[handslot].value;
p2 = computer[handslot].suit;
p3 = computer[handslot].deadwoodVal;
p4 = computer[handslot].orderVal;

computer[handslot].suit = computer[handslot + 1].suit;
computer[handslot].value = computer[handslot + 1].value;
computer[handslot].deadwoodVal =computer[handslot + 1].deadwoodVal;
computer[handslot].orderVal = computer[handslot + 1].orderVal;
computer[handslot + 1].value = p1;
computer[handslot +1].suit = p2;
computer[handslot +1].deadwoodVal =p3;
computer[handslot +1].orderVal =p4;
}}}//************************************


for(int x = 0; x < 152; ++x){
for(handslot = 0; handslot < (computer.size() -1); ++handslot){//====
if((computer[handslot].orderVal > computer[handslot + 1].orderVal)&&(computer[handslot].suit == computer[handslot + 1].suit)){
p1 = computer[handslot].value;
p2 = computer[handslot].suit;
p3 = computer[handslot].deadwoodVal;
p4 = computer[handslot].orderVal;

computer[handslot].suit = computer[handslot + 1].suit;
computer[handslot].value = computer[handslot + 1].value;
computer[handslot].deadwoodVal =computer[handslot + 1].deadwoodVal;
computer[handslot].orderVal = computer[handslot + 1].orderVal;
computer[handslot + 1].value = p1;
computer[handslot +1].suit = p2;
computer[handslot +1].deadwoodVal =p3;
computer[handslot +1].orderVal =p4;
}}};

}//end of SortC();







