#include <iostream>       // std::cout
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
#include <ctime>
#include <cstdlib>

#include "TestHands.cpp"
using namespace std;


Card discard[52];
//int discarded;
int disSel;
int dissize = 0; //discard size


discardTop(){ //Starts Discard Pile
// int discarded = 0;
 discard[0].value = deck2[draws].value;
 discard[0].suit = deck2[draws].suit;
 discard[0].orderVal = deck2[draws].orderVal;
 discard[0].deadwoodVal = deck2[draws].deadwoodVal;
 --amount;
 ++draws;
 ++dissize;
};


discardHand(){
 ++dissize;
 discard[dissize - 1].value = player[disSel - 1].value;
 discard[dissize - 1].suit = player[disSel - 1].suit;
 discard[dissize - 1].orderVal = player[disSel - 1].orderVal;
 discard[dissize - 1].deadwoodVal = player[disSel - 1].deadwoodVal;
  
 for(int i = disSel - 1; i < psize -1; ++i){
 player[i].value = player[i + 1].value;
 player[i].suit = player[i + 1].suit;
 player[i].orderVal = player[i + 1].orderVal;
 player[i].deadwoodVal = player[i + 1].deadwoodVal;
 }

--psize;	
};



drawDeck(){
	
 psize;
 player[psize].value = deck2[draws].value; 
 player[psize].orderVal = deck2[draws].orderVal; 
 player[psize].suit = deck2[draws].suit; 
 player[psize].deadwoodVal = deck2[draws].deadwoodVal; 
 ++psize;
 ++draws;
--amount;

cout << "****************************************************************" << endl;
cout << "\t\t\t::Players Hand::\n";
for(int i = 0; i < psize; ++i){cout << player[i].value << player[i].suit << "  ";}
cout << endl;
cout << "****************************************************************" << endl;

};


drawPile(){
	
 player[psize].value = discard[dissize - 1].value; 
 player[psize].orderVal = discard[dissize - 1].orderVal; 
 player[psize].suit = discard[dissize - 1].suit; 
 player[psize].deadwoodVal = discard[dissize - 1].deadwoodVal;
 ++psize; 
 --dissize;
 

cout << "****************************************************************" << endl;
cout << "\t\t\t::Players Hand::\n";
for(int i = 0; i < psize; ++i){cout << player[i].value << player[i].suit << "  ";}
cout << endl;
cout << "****************************************************************" << endl;

 
};
