#include <iostream>
#include <string> 
using namespace std;

char p1;
string p2;
int p3;
int p4;

class Card {
	private:
	public:
	string suit;	   				 	      //Card Suit
	char value; 							 //Card Value
	int deadwoodVal;						//Point Value of the card
	int orderVal;							//Sorting Value
	Card();
};
Card::Card(){}; 
