#include <iostream>
#include "Class.cpp"
using namespace std;

void MakeDeck(){
	
cout << "Default Deck Order" << endl; //Possible Values and Suits for each Card.

//string ClassSuits[4] =  { "\u2661", "\u2662", "\u2663", "\u2660" }; //Heart, Diamond, Club, Spade 
//Line above not outputting Ascii in Command Prompt, Double check linux Output

/* Current Sets Used 
string ClassSuits[4] =  { "_Spd", "_Hrt", "_Dia", "_Clb" }; //Spade, Heart, Diamond, Club
char NumValues[13] = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'}; //Accepted Values
*/

//Mixed Set for Debugging
string ClassSuits[4] =  { "_Spd", "_Clb", "_Hrt", "_Dia" }; //Heart, Diamond, Club, Spade
char NumValues[13] = {'K', '9', 'A', '8', '7', '6', 'Q', '5', 'T', 'J', '4', '2', '3'}; //Accepted Values

//Card Assignment
int CardID=0; 								//Card Number 0 through 51
Card MainDeck[52];							//Creates a Deck of Blank Cards
for(int i = 0; i < 4; ++i){					//Suit Assignment Loop
for(int j = 0; j < 13; ++j){				//Value Assignment Loop

	MainDeck[CardID].suit = ClassSuits[i]; //Sets The Card's Suit
	MainDeck[CardID].value = NumValues[j]; //Sets The Card's Value

//Assigns Deadwood Values to each Card
if(MainDeck[CardID].value == 'A'){
MainDeck[CardID].deadwoodVal = 1;	
}
else if ((MainDeck[CardID].value == 'T')||(MainDeck[CardID].value == 'J')||(MainDeck[CardID].value == 'Q')||(MainDeck[CardID].value == 'K')){
MainDeck[CardID].deadwoodVal = 10;
}
else if((MainDeck[CardID].value <= '9')&&(MainDeck[CardID].value >= '2')){
MainDeck[CardID].deadwoodVal = MainDeck[CardID].value - '0';
};


//Order Weight
if(MainDeck[CardID].value == 'A'){
MainDeck[CardID].orderVal = 1;	
}
else if (MainDeck[CardID].value == 'T'){
MainDeck[CardID].orderVal = 10;
}
else if (MainDeck[CardID].value == 'J'){
MainDeck[CardID].orderVal = 11;
}
else if (MainDeck[CardID].value == 'Q'){
MainDeck[CardID].orderVal = 12;
}
else if (MainDeck[CardID].value == 'K'){
MainDeck[CardID].orderVal = 13;
}
else if((MainDeck[CardID].value <= '9')&&(MainDeck[CardID].value >= '2')){
MainDeck[CardID].orderVal = MainDeck[CardID].value - '0';
};

//Debug:: Outputs Card and Deadwood Value
//cout << MainDeck[CardID].value << MainDeck[CardID].suit << "  " << MainDeck[CardID].deadwoodVal << "  " << MainDeck[CardID].orderVal<< endl;


++CardID; 								//Moves to the next Blank Card
};
};

}


