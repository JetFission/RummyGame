#include <iostream>
#include "Discard Pile.cpp"
using namespace std;



char ActionInput;
int Pscore = 0; //players total score
int Cscore = 0; //comp's total score
int PHDead; //deadwood in players hand
int CHDead; //deadwood in computers hand
int Stocksize = 0; //decl size;
int roundnum; //





void MakeTable(){
cout << "****************************************************************" << endl;
cout << "* Player Score:" << Pscore << "\tStock Size:" << amount << "\t\tTop Card:" << discard[dissize - 1].value << discard[dissize - 1].suit << " *" << endl;
cout << "* Computer Score:" << Cscore << "\tDiscard Size:" << dissize << "\t\tRound:" << roundnum << "\t       *" <<endl;
cout << "****************************************************************" << endl;

cout << "\t\t\t::Computers Hand::\n";
for(int i = 0; i < csize; ++i){
cout << "?????  ";	//Default
//cout << computer[i].value << computer[i].suit << "  "; //Debug Code
}
cout << "\n\n";
cout << "\t\t\t::Players Hand::\n";
for(int i = 0; i < csize; ++i){
cout << player[i].value << player[i].suit << "  ";
}
cout << endl;
cout << "****************************************************************" << endl;
cout << "Melds:: " << "[Place Holder]" << endl;
cout << "Dead Wood:: " << "[Place Holder]" << endl;
cout << "****************************************************************" << endl;
}

action(){
int stop = 1;

while(stop == 1){
	
cout << "\t\t\t::Player Actions::" << endl;
cout <<"\tA)Draw Stock\tB)Draw Pile\tC)Rules\tD)Exit" << endl;
cout <<"\t\t     ::Please Select Action::";
cout <<"\n\t\t        \\_::";
cin >> ActionInput;
cout << endl;

if((ActionInput == 'A')||(ActionInput == 'a')){
drawDeck();
stop = 0;
}
else if((ActionInput == 'B')||(ActionInput == 'b')){
drawPile();
stop = 0;
}else if((ActionInput == 'C')||(ActionInput == 'c')){
system ("start rules.exe");
}
else{cout << "Invalid Selection" << endl;}

}


cout << "\t\t\t::Player Actions::" << endl;
cout <<"\t\t     ::Please Discard A Card::";
cout <<"\n\t\t        \\_::";
cin >> disSel;
discardHand();


}





int main(){

PrepareDeck(); //Deals Starting Hands
Deal();
discardTop();
SortP(); //Sorts Player Hand
SortC(); //Sorts Comp Hand
MakeTable(); //Sets up Game Board

int turns = 0;
while(turns < 3){//debug loop
	

action();
SortP(); //Sorts Player Hand
cout << "\n\n" << endl;	
MakeTable();

++turns;
}
/*
for(int i = draws; i < 52; ++i){
cout << deck2[i].value << deck2[i].suit << "   " << i << endl;
}
cout << endl;


for(int i = 0; i < psize; ++i){cout << player[i].value << player[i].suit << "  ";}
cout << endl;
for(int i = 0; i < csize; ++i){cout << computer[i].value << computer[i].suit << "  ";}
cout << endl;
*/

return 0;
}
