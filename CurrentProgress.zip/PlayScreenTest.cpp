#include <iostream>
#include "TestHands.cpp"
using namespace std;


int csize = 10;	
int psize = 10;	
char ActionInput;
int Pscore = 0; //players total score
int Cscore = 0; //comp's total score
int PHDead; //deadwood in players hand
int CHDead; //deadwood in computers hand
int Stocksize = 0; //decl size;
int dissize = 0; //discard size
int roundnum; //





void MakeTable(){
cout << "****************************************************************" << endl;
cout << "* Player Score:" << Pscore << "\tStock Size:" << amount << "\t\tTop Card:" << "XX" << "    *" << endl;
cout << "* Computer Score:" << Cscore << "\tDiscard Size:" << dissize << "\t\tRound:" << roundnum << "\t       *" <<endl;
cout << "****************************************************************" << endl;

cout << "\t\t\t::Computers Hand::\n";
for(int i = 0; i < csize; ++i){
cout << computer[i].value << computer[i].suit << "  ";
}

cout << "\n\n";

cout << "\t\t\t::Players Hand::\n";
for(int i = 0; i < csize; ++i){
cout << player[i].value << player[i].suit << "  ";
}
cout << endl;
cout << "****************************************************************" << endl;
cout << "Melds:: " << "[Place Holder]" << endl;
cout << "Dead Wood:: " << "[Place Holder]" << endl;
cout << "****************************************************************" << endl;
cout << "\t\t\t   ::Player Actions::" << endl;
cout <<"\t\tA)Play\tB)Draw\tC)Move\tD)View\tE)Exit" << endl;
cout <<"\t\tPlease Select Action::";
cin >> ActionInput;
cout << endl;
}




int main(){

PrepareDeck(); //Deals Starting Hands
Deal();
//SortP(); //Sorts Player Hand
//SortC(); //Sorts Comp Hand
//MakeTable(); //Sets up Game Board	


for(int i = 0; i < deck.size(); ++i){
cout << deck[i].value << deck[i].suit << "   " << i << endl;
}
cout << endl;

/*
for(int i = 0; i < csize; ++i){cout << player[i].value << player[i].suit << "  ";}
cout << endl;
for(int i = 0; i < csize; ++i){cout << computer[i].value << computer[i].suit << "  ";}
*/

return 0;
}
